# glucodiary
"Diario de glucosa simple y amigable para monitoreo diario"
